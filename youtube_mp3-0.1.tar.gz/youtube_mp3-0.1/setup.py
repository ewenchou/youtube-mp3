from setuptools import setup

setup(name='youtube_mp3',
      version='0.1',
      description='Python helper for extracting audio from Youtube videos as MP3',
      url='',
      author='Ewen Chou',
      author_email='ewenchou@gmail.com',
      license='',
      packages=['youtube_mp3'],
      zip_safe=False)